<?php
/**
* Plugin Name: Hardik Graphql
* Version: 1.0
* Author: Hardik Chavada
* Description: This plugin generated to create custom queries and mutations for graphql
* Text Domain: hardik-graphql
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

require __DIR__ . '\vendor\autoload.php';

use HardikGraphql\Mutations\RegisterGraphQlMutations;
use HardikGraphql\Queries\RegisterGraphQlQueries;

// include_once plugin_dir_path( __FILE__ ) . '_classes/Mutations/RegisterGraphQlMutations.php';

$mutationsObj = new RegisterGraphQlMutations();
$queryObj = new RegisterGraphQlQueries();







