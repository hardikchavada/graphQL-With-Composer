<?php

namespace HardikGraphql\Queries; 
//for namespacing just add the namespace and the folder name in which the class file is present(check in composer.json)

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class RegisterGraphQlQueries {	

	//Adding a constructor
	public function __construct() {	
		$this->register_graphql_queries();		
	}

	public function register_graphql_queries() {

		add_action('graphql_register_types', array($this, 'hardik_create_field_wo_args') );	
		
		add_action('graphql_register_types', array($this, 'hardik_create_field_with_args') );

	}

	//create a GraphQL field without arguments
	public function hardik_create_field_wo_args() {
		/**
		 * Type following in graphiQL IDE
		 * query MyQuery {
		 * testField
		 * }
		 */
		register_graphql_field( 'RootQuery', 'testField', [
			'type'  => 'String',
			'description' => __('This is a test field', 'hardik-graphql' ),
			'resolve' => function() {
				return 'This is a testField';
			}
		]);
	}

	//createe a GraphQL field with arrguments
	public function hardik_create_field_with_args() {
		/**
		 * Type following in graphiQL IDE
		 * query MyQuery {
		 * newFieldWithArgs(arg2: 10)
		 * }
		 */
		$config = [
			'type' => 'String',
			'args' => [
				'myArg' => [
					'type' => 'String'
				],
				'arg2' => [
					'type' => 'Integer'
				]
			],
			'resolve' => function($source, $args) {
				return ' The value you typed is: '. $args['myArg'] . ', '. $args['arg2'];
			}

		];
		register_graphql_field( 'RootQuery', 'NewFieldWithArgs', $config);
	}
	
}
