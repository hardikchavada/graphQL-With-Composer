<?php

namespace HardikGraphql\Mutations; 
//for namespacing just add the namespace and the folder name in which the class file is present(check in composer.json)

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class RegisterGraphQlMutations {	

	//Adding a constructor
	public function __construct() {			
		$this->register_graphql_mutataions();
	}

	public function register_graphql_mutataions() {
		add_action( 'graphql_register_types', array($this, 'hardik_register_basic_mutation') );

		add_action( 'graphql_register_types', array($this, 'hardik_delete_post_by_mutation') );
	}
	
	//Register a Basic Mutation
	public function hardik_register_basic_mutation() {
		/**
		 * mutation MyMutation {
		 *	testMutation(input: {phoneNumber: "46554"}) {
		 *		phoneNumber
		 *	}
		 *	}
		 */
		register_graphql_mutation( 'testMutation', [
			'inputFields' => [
				'phoneNumber' => [
					'type' => 'String',
				],
			],
			'outputFields' => [
				'phoneNumber' => [
					'type' => 'String',
				],
			],
			'mutateAndGetPayload' => function( $input ) {

				return [
					'phoneNumber' => 'The value entered is '.$input['phoneNumber'] ?? null,
				];

			}
		]);
	}

	//Mutation: Delete a Post thru Mutation by insertiing ID
	public function hardik_delete_post_by_mutation() {
		/**
		 *  mutation MyMutation {
	     *	deletePostByID(input: {postID: "300"}) {
		 *	postID
		 *	}
		 *	}
		 */
		register_graphql_mutation( 'deletePostByID', [
			'inputFields' => [
				'postID' => [
					'type' => 'String',
				],
			],
			'outputFields' => [
				'postID' => [
					'type' => 'String',
				],
			],
			'mutateAndGetPayload' => function( $input ) {
				$post_id = (int)$input['postID'];
	
				// if(FALSE === get_post_status($post_id)) {
				// 	return;
				// }
				
				wp_delete_post( $post_id); 
				return [
					'postID' => 'Deleted Post is: '.$post_id,
				];
	
			}
		]);
	}

	
}
